from argparse import ArgumentParser
from my_mod.step import Step
from my_mod.conversion_strategy import BorderingStrategy, GaussianBlurStrategy, \
    AffineTransformationStrategy, RotateStrategy
import cv2 as cv
import time
import datetime


def main():
    parser = ArgumentParser(
        description='INSERT path to image you want to change, and path where to save changed image'
                    'EXAMPLE: python3 main.py /home/adam/Python1/lab_3_zadanie_4/starry_night.jpg '
                    '/home/adam/Python1/lab_3_zadanie_4/starry_night_new.jpg')
    parser.add_argument('filepath1')
    parser.add_argument('filepath2')
    args = parser.parse_args()

    step1 = Step(BorderingStrategy(args.filepath1, args.filepath2))
    step2 = Step(GaussianBlurStrategy(args.filepath2, args.filepath2))
    step3 = Step(RotateStrategy(args.filepath2, args.filepath2))
    step4 = Step(AffineTransformationStrategy(args.filepath2, args.filepath2))
    step5 = Step(RotateStrategy(args.filepath2, args.filepath2))
    step1.convert()
    step2.convert()
    step3.convert()
    step4.convert()
    step5.convert()


if '__main__' == __name__:
    main()

