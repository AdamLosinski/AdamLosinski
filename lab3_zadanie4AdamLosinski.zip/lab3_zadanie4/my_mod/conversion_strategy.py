import cv2 as cv
from cv2 import rotate, ROTATE_90_CLOCKWISE
import sys
import numpy as np


class ConversionStrategy:
    def __init__(self, image_path, new_image_path):
        self.new_image_path = new_image_path
        self.img = cv.imread(image_path)
        if self.img is None:
            sys.exit("Could not read the image.")

    def __call__(self):
        pass


class BorderingStrategy(ConversionStrategy):
    def __call__(self):
        self.dst = cv.copyMakeBorder(self.img, 100, 100, 100, 100, cv.BORDER_REFLECT)
        cv.imwrite(self.new_image_path, self.dst)


class GaussianBlurStrategy(ConversionStrategy):
    def __call__(self):
        self.dst = cv.GaussianBlur(self.img, (5, 5), 0)
        cv.imwrite(self.new_image_path, self.dst)


class AffineTransformationStrategy(ConversionStrategy):
    def __call__(self):
        self.rows, self.cols, self.ch = self.img.shape
        self.pts1 = np.float32([[50, 50], [200, 50], [50, 200]])
        self.pts2 = np.float32([[10, 100], [200, 50], [100, 250]])
        self.M = cv.getAffineTransform(self.pts1, self.pts2)
        self.dst = cv.warpAffine(self.img, self.M, (self.cols, self.rows))
        cv.imwrite(self.new_image_path, self.dst)


class RotateStrategy(ConversionStrategy):
    def __call__(self):
        self.rows, self.cols, self.ch = self.img.shape
        self.M = cv.getRotationMatrix2D(((self.cols - 1) / 2.0, (self.rows - 1) / 2.0), 90, 1)
        self.dst = cv.warpAffine(self.img, self.M, (self.cols, self.rows))
        cv.imwrite(self.new_image_path, self.dst)
