class Step:
    def __init__(self, conversion_strategy):
        self.__conversion_strategy = conversion_strategy

    @property
    def conversion_strategy(self):
        return self.__conversion_strategy

    @conversion_strategy.setter
    def conversion_strategy(self, obj):
        self.__conversion_strategy = obj

    def convert(self):
        self.__conversion_strategy()
