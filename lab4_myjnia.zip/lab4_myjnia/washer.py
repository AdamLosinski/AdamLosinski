from timeit import default_timer as timer


class Washer:
    def __init__(self, wash_strategy):
        self.__wash_strategy = wash_strategy

    def __call__(self, car_part_to_wash):
        start = timer()
        self.__wash_strategy.wash(car_part_to_wash)
        print(car_part_to_wash)
        print('It took {0}'.format(timer() - start))
