import time


def bubble(part):
    print("Spraying " + part + " with foam")
    time.sleep(0.1)
    print("Waiting 3 sec for active foam to work on " + part)
    time.sleep(0.1)
    for i in range(1, 4):
        print(i)
        time.sleep(1)
    print("Rinsing " + part)
    time.sleep(0.1)
    print("Process ended. " + part + " is cleaned")


def pressure(part):
    print("Setting high pressure on nozzle")
    time.sleep(0.1)
    print("Cleaning for 4 sec " + part + " with high pressure watter")
    time.sleep(0.1)
    for i in range(1, 5):
        print(i)
        time.sleep(1)
    print("Process ended. " + part + " is cleaned")
