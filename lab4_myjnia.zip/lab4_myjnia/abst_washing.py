from abc import ABC, abstractmethod
from washlib import bubble, pressure


class AbstractWashing(ABC):
    def __init__(self):
        pass

    @abstractmethod
    def wash(self, array):
        pass


class BubbleWashing(AbstractWashing):
    def __init__(self):
        super().__init__()

    def wash(self, car_part):
        bubble(car_part)


class PressureWashing(AbstractWashing):
    def __init__(self):
        super().__init__()

    def wash(self, car_part):
        pressure(car_part)
