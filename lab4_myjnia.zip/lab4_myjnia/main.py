from washer import Washer
from abst_washing import BubbleWashing, PressureWashing


def main():
    washer_1 = Washer(BubbleWashing())
    washer_2 = Washer(PressureWashing())

    washer_1('karoseria')
    washer_2('koła')


if '__main__' == __name__:
    main()
