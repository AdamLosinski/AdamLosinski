class StudentDoesntExist(Exception):
    pass


class StudentAlreadyExists(Exception):
    pass
