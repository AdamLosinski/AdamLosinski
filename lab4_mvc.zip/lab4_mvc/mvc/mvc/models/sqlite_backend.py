import sqlite3
from sqlite3 import OperationalError, IntegrityError, ProgrammingError
from .mvc_exceptions import StudentDoesntExist, StudentAlreadyExists

DB_name = 'Gradebook'


def connect_to_db(db=None):
    if db is None:
        gradebook = ':memory:'
        print('New conection to in-memory SQLite DB...')
    else:
        gradebook = '{}.db'.format(db)
        print('New conection to SQLite DB...')
    connection = sqlite3.connect(gradebook)
    return connection


def connect(func):
    def inner_func(conn, *args, **kwargs):
        try:
            conn.execute(
                'SELECT name FROM sqlite_temp_master WHERE type="table";')
        except (AttributeError, ProgrammingError):
            conn = connect_to_db(DB_name)
        return func(conn, *args, **kwargs)
    return inner_func


def disconect_from_db(db=None, conn=None):
    if db is not DB_name:
        print("You are trying to disconnect from a wrong DB")
    if conn is not None:
        conn.close()


@connect
def create_table(conn, table_name):
    sql = 'CREATE TABLE {} (rowid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, lastname TEXT, grade1 INTEGER,' \
          'grade2 INTEGER, grade3 INTEGER, grade4 INTEGER)'.format(table_name)
    try:
        conn.execute(sql)
    except OperationalError as e:
        print(e)


@connect
def add_student(conn, name, lastname, table_name):
    sql = "INSERT INTO {} ('name', 'lastname') VALUES (?,?)".format(table_name)
    try:
        conn.execute(sql, (name, lastname))
        conn.commit()
    except IntegrityError as e:
        raise StudentAlreadyExists(
            '{}:"{} {}" already stored in table "{}"'.format(e, name, lastname, table_name))


def tuple_to_dict(mytuple):
    mydict = dict()
    mydict['id'] = mytuple[0]
    mydict['name'] = mytuple[1]
    mydict['lastname'] = mytuple[2]
    mydict['grade1'] = mytuple[3]
    mydict['grade2'] = mytuple[4]
    mydict['grade3'] = mytuple[5]
    mydict['grade4'] = mytuple[6]
    return mydict


@connect
def read_student_data(conn, student_lastname, table_name):
    sql = 'SELECT *FROM {} WHERE lastname="{}"'.format(table_name, student_lastname)
    c = conn.execute(sql)
    result = c.fetchone()
    if result is not None:
        return tuple_to_dict(result)
    else:
        raise StudentDoesntExist(
            'Can\'t read "{}" because it doesnt exist in table "{}"'.format(student_lastname, table_name))


@connect
def add_grade(conn, lastname, grade, table_name):
    sql_check = 'SELECT EXISTS(SELECT 1 FROM {} WHERE lastname=? LIMIT 1)'.format(table_name)
    sql_get = 'SELECT * FROM {} WHERE lastname=?'.format(table_name)
    sql_update1 = 'UPDATE {} SET grade1=? WHERE lastname=?'.format(table_name)
    sql_update2 = 'UPDATE {} SET grade2=? WHERE lastname=?'.format(table_name)
    sql_update3 = 'UPDATE {} SET grade3=? WHERE lastname=?'.format(table_name)
    sql_update4 = 'UPDATE {} SET grade4=? WHERE lastname=?'.format(table_name)
    c = conn.execute(sql_check, (lastname,))
    result = c.fetchone()
    if result[0]:
        c = conn.execute(sql_get, (lastname,))
        result = c.fetchone()
        if not result[3] and not result[4] and not result[5] and not result[6]:
            c.execute(sql_update1, (grade, lastname,))
            conn.commit()
        elif result[3] and not result[4] and not result[5] and not result[6]:
            c.execute(sql_update2, (grade, lastname,))
            conn.commit()
        elif result[3] and result[4] and not result[5] and not result[6]:
            c.execute(sql_update3, (grade, lastname,))
            conn.commit()
        elif result[3] and result[4] and result[5] and not result[6]:
            c.execute(sql_update4, (grade, lastname,))
            conn.commit()
        else:
            c.execute(sql_update4, (grade, lastname,))
            conn.commit()
    else:
        raise StudentDoesntExist(
            'Can\'t update "{}" cecause student doesn\'t exist in table "{}"'.format(lastname, table_name))
