from .abstract_model import AbstractModel
from .sqlite_backend import add_grade, add_student, read_student_data, connect_to_db, DB_name, create_table



class GradebookModel(AbstractModel):
    def __init__(self):
        super().__init__()
        self.__gradebook_name = 'Gradebook'
        self.__conection = connect_to_db(DB_name)
        create_table(self.__conection, self.__gradebook_name)

    @property
    def connection(self):
        return self.__conection

    @property
    def gradebook_name(self):
        return self.__gradebook_name

    @gradebook_name.setter
    def gradebook_name(self, new_gradebook_name):
        self.__gradebook_name = new_gradebook_name

    def add_student(self, name, lastname):
        add_student(self.connection, name, lastname, table_name=self.__gradebook_name)
        self.notify("add_Student", name, lastname)

    def add_grade(self, lastname, grade):
        add_grade(self.connection, lastname, grade, table_name=self.__gradebook_name)
        self.notify("add_grade", lastname, grade)

    def read_student_data(self, lastname):
        student_data = read_student_data(self.__conection, lastname, table_name=self.__gradebook_name)
        print(student_data)

        if student_data["grade1"] is None and student_data["grade2"] is None and student_data["grade3"] is None and student_data["grade4"] is None:
            average = 0
        elif student_data["grade1"] is not None and student_data["grade2"] is None and student_data["grade3"] is None and student_data["grade4"] is None:
            keys = ['grade1']
            student_grades = {x: student_data[x] for x in keys}
            average = (student_grades["grade1"])
        elif student_data["grade1"] is not None and student_data["grade2"] is not None and student_data["grade3"] is None and student_data["grade4"] is None:
            keys = ['grade1', 'grade2']
            student_grades = {x: student_data[x] for x in keys}
            average = (student_grades["grade1"] + student_grades["grade2"]) / 2
        elif student_data["grade1"] is not None and student_data["grade2"] is not None and student_data["grade3"] is not None and student_data["grade4"] is None:
            keys = ['grade1', 'grade2', 'grade3']
            student_grades = {x: student_data[x] for x in keys}
            average = (student_grades["grade1"] + student_grades["grade2"] + student_grades["grade3"]) / 3
        else:
            keys = ['grade1', 'grade2', 'grade3', 'grade4']
            student_grades = {x: student_data[x] for x in keys}
            average = (student_grades["grade1"] + student_grades["grade2"] + student_grades["grade3"] + student_grades["grade4"]) / 4
        self.notify("read_student_data", student_data, average)

    def notify(self, *args, **kwargs):
        for obs in self._obs_list.values():
            obs.update(*args, **kwargs)
