from controllers.console_gradebook_controller import ConsoleGradebookController
from controllers.console2_gradebook_controller import Console2GradebookController
from controllers.app import ConsoleApp
from controllers.app2 import Console2App
from mvc.models.sqlite_backend import connect_to_db, DB_name


def main_console2():
    controller = Console2GradebookController()
    app = Console2App(controller)
    app.run_app()


def main_console():
    conn = connect_to_db(DB_name)
    controller = ConsoleGradebookController()
    app = ConsoleApp(controller)
    app.run_app()


if '__main__' == __name__:
    main_console2()
