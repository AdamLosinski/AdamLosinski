from .abstract_view import AbstractView


class Console2GradebookView(AbstractView):
    def __init__(self, name, model):
        super().__init__(name, model)

    def add_component(self, comp):
        pass

    def update(self, *args, **kwargs):
        if args[0] == 'add_student':
            print('Student {0} {1} was added to Gradebook, and we are now using second tipe of view with much longer '
                  'description that are not useful at all'.format(args[1], args[2]))

        elif args[0] == 'add_grade':
            print('Grade added to student {0} of a value {1}. As before we are again in second console view with '
                  'longer descriptions just to show that its different than other view. There is nothig else in this '
                  'view except of those descriptions'.format(args[1], args[2]))

        elif args[0] == 'read_student_data':
            print('Student data {0} with grades average of: {1} Congratulation due to youre perfect grades average, '
                  'let\'s show it again {2} and again {3} and one more time {4}'.format(args[1], args[2], args[2],
                                                                                        args[2], args[2]))

        else:
            print('Incorrect data')

    def show(self):
        self.model.notify()