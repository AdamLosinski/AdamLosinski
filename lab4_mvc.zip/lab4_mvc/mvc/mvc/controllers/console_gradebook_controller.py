from .abstract_controller import AbstractController


class ConsoleGradebookController(AbstractController):
    def __init__(self, model=None, view=None):
        super().__init__(model, view)

    def get_user_input(self):
        obj = input('Type q to quit, a to add student, g to add grade, s to show student data:\n')
        if obj == 'q':
            return False
        elif obj == 's':
            lastname = input('Insert student lastname to show data:\n')
            self.model.read_student_data(lastname)

        elif obj == 'a':
            name = input('Insert student name \n')
            lastname = input('Insert student lastname \n')
            self.model.add_student(name, lastname)

        elif obj == 'g':
            lastname = input('Insert id of student\'s you want to grade \n')
            grade = input('Insert grade \n')
            self.model.add_grade(lastname, grade)
        else:
            print('Incorrect value')
        return True
