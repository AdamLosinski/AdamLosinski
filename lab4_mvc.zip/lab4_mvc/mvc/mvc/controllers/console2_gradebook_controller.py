from .abstract_controller import AbstractController


class Console2GradebookController(AbstractController):
    def __init__(self, model=None, view=None):
        super().__init__(model, view)

    def get_user_input(self):
        obj = input('Type "quit" to quit, "add"to add student, "grade" to add grade, "show" to show student data:\n')
        if obj == 'quit':
            return False
        elif obj == 'show':
            lastname = input('Insert student lastname to show data:\n')
            self.model.read_student_data(lastname)

        elif obj == 'add':
            name = input('Insert student name \n')
            lastname = input('Insert student lastname \n')
            self.model.add_student(name, lastname)

        elif obj == 'grade':
            lastname = input('Insert lastname of student\'s you want to grade \n')
            grade = input('Insert grade \n')
            self.model.add_grade(lastname, grade)
        else:
            print('Incorrect value \n')
        return True
