import time
import progressbar

class Subject:
    def __init__(self):
        self.__obs_list = []

    def add_observer(self, obs):
        self.__obs_list.append(obs)

    def progress_bar(self):
        for i in progressbar.progressbar(range(100)):
            Subject.notify(self, i)
            time.sleep(0.02)

    def notify(self, *args, **kwargs):
        for obs in self.__obs_list:
                obs.update(*args, **kwargs)
