import time
import progressbar
from subject import Subject
from observer import FirstObserver, SecondObserver

def main():
    subject = Subject()
    subject.add_observer(FirstObserver())
    subject.add_observer(SecondObserver())
    subject.progress_bar()






if '__main__' == __name__:
    main()
