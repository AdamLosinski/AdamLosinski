from composite import Composite
from leaf import Leaf


def main():
    leaf_1 = Leaf('dysk', 1)
    leaf_2 = Leaf('płyta główna', 2)
    leaf_3 = Leaf('karta', 3)

    composite_1 = Composite('płyta montażowa', 4)
    composite_1.add_component(leaf_1)
    composite_1.add_component(leaf_2)

    composite_2 = Composite('magistrala', 5)
    composite_2.add_component(leaf_3)

    composite_3 = Composite('obudowa', 6)
    composite_3.add_component(composite_1)
    composite_3.add_component(composite_2)

    composite_3.do_operation()


if '__main__' == __name__:
    main()
