from component import Component


class Leaf(Component):
    def __init__(self, comp_id, comp_price):
        super().__init__(comp_id, comp_price)

    def do_operation(self):
        print('{0} {1} costs {2}'.format(self.prefix, self.id, self.price))